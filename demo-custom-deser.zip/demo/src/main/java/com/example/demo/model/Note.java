package com.example.demo.model;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Note {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;

	private String title;

	@JsonDeserialize(contentUsing = CustomStringToLongDeserializer.class)
	private List<Long> entries;

	protected Note() {}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public List<Long> getEntries() {
		return entries;
	}

	public void setEntries(List<Long> entries) {
		this.entries = entries;
	}

}

package com.example.demo.model;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;
import com.fasterxml.jackson.databind.node.TextNode;

public class CustomStringToLongDeserializer extends StdDeserializer<Long> {

	private static final long serialVersionUID = 1L;

	public CustomStringToLongDeserializer() {
		this(null);
	}

	public CustomStringToLongDeserializer(Class<Long> t) {
		super(t);
	}

	@SuppressWarnings("unused")
	@Override
	public Long deserialize(JsonParser parser, DeserializationContext ctxt) {
		try {
			if (parser.getCodec().readTree(parser) instanceof TextNode textNode) {
				String url = textNode.asText();
				int idPosition = url.lastIndexOf(":");
				if (idPosition > -1) {
					return Long.valueOf(url.substring(idPosition + 1));
				}
			}
		} catch (Throwable e) {
			throw new IllegalArgumentException("Failed to deserialize", e);
		}
		throw new IllegalArgumentException("Failed to deserialize");
	}
}
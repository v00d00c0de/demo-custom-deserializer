package com.example.demo.repository;

import com.example.demo.model.Note;

import org.springframework.data.repository.CrudRepository;

public interface NoteRepository extends CrudRepository<Note, Long> {

}
